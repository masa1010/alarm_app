// This is a JavaScript file
//アラームフラグを初期化する。
var flg =0;


//時刻更新＆アラームチェックファンクション
function timeCheck(){
    //時刻を取得。
	Now = new Date();

	Hour = Now.getHours();
	Min = Now.getMinutes();
	Sec = Now.getSeconds();
    
	//時刻をチェック。
	if((Number(document.getElementById(alermH).value) == Hour) &&
		(Number(document.getElementById(alermM).value) == Min)){
		alart('時間です') ;
	}

	//次の更新をセットする。
	setInterval("timeCheck();",100);
}



