// This is a JavaScript file

function alarm_set(){
    
}
